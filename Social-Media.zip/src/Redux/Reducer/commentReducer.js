// import { COMMENT} from "../Type/Type";

// let initialState = {
//     comment: []
// };
// export const commentReducer = (state = initialState, action) => {
//     switch (action.type) {
//         case COMMENT:
//             return {
//                 comment: [...action.data]
//             };
//         default:
//             return state;
//     }
// }