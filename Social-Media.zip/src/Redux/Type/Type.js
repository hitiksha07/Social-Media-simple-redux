export let USER = 'user';
export let POST = 'post';
export let COMMENT = 'comment';
export let LIKE = 'like';
export let COMMENTUPDATE = 'commentUpdate';
export let DELETECOMMENT = 'deletecomment';
export let ADDCOMM = 'addcomm';